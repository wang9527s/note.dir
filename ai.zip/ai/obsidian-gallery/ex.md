# Gallery 相册插件演示

## 风景相册

```gallery
![[sunset.svg|日落晚霞]]
![[mountains.svg|星空山脉]]
![[ocean.svg|碧海蓝天]]
![[forest.svg|静谧森林]]
![[aurora.svg|极光之夜]]
![[cherry-blossom.svg|樱花盛开]]
```

---

## 使用说明

在代码块中使用 `gallery` 语言标记，每行写一张图片即可。

### 交互方式

| 操作 | 说明 |
|---|---|
| `← →` 按钮 | 鼠标悬停时出现，点击切换上/下一张 |
| 底部圆点 | 点击直接跳转到指定图片 |
| 触屏滑动 | 手指左右滑动切换 |
| 鼠标拖拽 | 鼠标按住左右拖动切换 |
| 键盘方向键 | 点击相册区域后，按 ← → 键切换 |
| 点击图片 | 全屏预览，再次点击或按 Esc 退出 |

### 语法格式

**Wiki-link 语法（推荐，支持 vault 内图片）：**

````
```gallery
![[photo1.jpg]]
![[photo2.png|图片说明文字]]
![[subfolder/photo3.jpg]]
```
````

**Markdown 语法（支持外部链接）：**

````
```gallery
![说明文字](https://example.com/image.jpg)
![](path/to/local.png)
```
````

## 启用步骤

1. 打开 Obsidian → 设置 → 第三方插件
2. 关闭「安全模式」
3. 在已安装插件列表中找到 **Gallery AI** 并启用
4. 回到本页查看效果
