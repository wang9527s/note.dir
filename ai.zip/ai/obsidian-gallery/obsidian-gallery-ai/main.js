/*
 * Obsidian Gallery Plugin
 *
 * Usage — put a fenced code block with language "gallery" in your note:
 *
 * ```gallery
 * ![[photo1.jpg]]
 * ![[photo2.png|My caption]]
 * ![[subfolder/photo3.jpg]]
 * ```
 *
 * Or use markdown image syntax:
 *
 * ```gallery
 * ![caption1](https://example.com/img1.jpg)
 * ![caption2](path/to/local.png)
 * ```
 *
 * Supports: click prev/next buttons, swipe/drag, dot indicators,
 *           keyboard arrows, counter badge, click‑to‑fullscreen.
 */

"use strict";

const { Plugin } = require("obsidian");

// ──────────────────────────────────────────────
// SVG icons
// ──────────────────────────────────────────────
const CHEVRON_LEFT =
  '<svg viewBox="0 0 24 24"><polyline points="15 18 9 12 15 6"/></svg>';
const CHEVRON_RIGHT =
  '<svg viewBox="0 0 24 24"><polyline points="9 6 15 12 9 18"/></svg>';

// ──────────────────────────────────────────────
// Helpers
// ──────────────────────────────────────────────

/** Parse a code block body into [{src, caption}] */
function parseImages(source, app) {
  const lines = source.split("\n").map((l) => l.trim()).filter(Boolean);
  const images = [];

  for (const line of lines) {
    // Wiki‑link:  ![[file.png]]  or  ![[file.png|caption]]
    const wikiMatch = line.match(/^!\[\[([^\]|]+?)(?:\|([^\]]*))?\]\]$/);
    if (wikiMatch) {
      const fileName = wikiMatch[1].trim();
      const caption = (wikiMatch[2] || "").trim();
      // Resolve through Obsidian's vault
      const file = app.metadataCache.getFirstLinkpathDest(fileName, "");
      if (file) {
        images.push({
          src: app.vault.getResourcePath(file),
          caption,
        });
      }
      continue;
    }

    // Markdown image:  ![alt](url)
    const mdMatch = line.match(/^!\[([^\]]*)\]\(([^)]+)\)$/);
    if (mdMatch) {
      images.push({
        src: mdMatch[2].trim(),
        caption: mdMatch[1].trim(),
      });
      continue;
    }
  }

  return images;
}

// ──────────────────────────────────────────────
// Gallery renderer
// ──────────────────────────────────────────────

function renderGallery(images, containerEl) {
  if (images.length === 0) {
    containerEl.createEl("p", { text: "No images found." });
    return;
  }

  let current = 0;
  const total = images.length;

  // --- Container ---
  const container = containerEl.createDiv({ cls: "gallery-container" });
  container.tabIndex = 0; // make focusable for keyboard

  // --- Viewport ---
  const viewport = container.createDiv({ cls: "gallery-viewport" });

  // Counter badge
  const counter = container.createDiv({ cls: "gallery-counter" });

  // Track (flex row of slides)
  const track = viewport.createDiv({ cls: "gallery-track" });

  for (const img of images) {
    const slide = track.createDiv({ cls: "gallery-slide" });
    const imgEl = slide.createEl("img", { attr: { src: img.src, alt: img.caption || "", loading: "lazy" } });

    // Click to fullscreen
    imgEl.addEventListener("click", () => {
      openFullscreen(img.src);
    });
  }

  // --- Buttons ---
  const prevBtn = container.createDiv({ cls: "gallery-btn gallery-btn-prev" });
  prevBtn.innerHTML = CHEVRON_LEFT;
  prevBtn.setAttribute("role", "button");
  prevBtn.ariaLabel = "Previous";

  const nextBtn = container.createDiv({ cls: "gallery-btn gallery-btn-next" });
  nextBtn.innerHTML = CHEVRON_RIGHT;
  nextBtn.setAttribute("role", "button");
  nextBtn.ariaLabel = "Next";

  // --- Caption ---
  const captionEl = container.createDiv({ cls: "gallery-caption" });

  // --- Dots ---
  const dotsContainer = container.createDiv({ cls: "gallery-dots" });
  const dots = [];
  for (let i = 0; i < total; i++) {
    const dot = dotsContainer.createEl("button", { cls: "gallery-dot" });
    dot.ariaLabel = `Go to image ${i + 1}`;
    dot.addEventListener("click", () => goTo(i));
    dots.push(dot);
  }

  // --- State helpers ---
  function update() {
    track.style.transform = `translateX(-${current * 100}%)`;
    counter.textContent = `${current + 1} / ${total}`;
    captionEl.textContent = images[current].caption || "";
    captionEl.style.display = images[current].caption ? "" : "none";
    dots.forEach((d, i) => d.classList.toggle("active", i === current));
  }

  function goTo(index) {
    current = ((index % total) + total) % total;
    update();
  }

  function next() {
    goTo(current + 1);
  }
  function prev() {
    goTo(current - 1);
  }

  prevBtn.addEventListener("click", prev);
  nextBtn.addEventListener("click", next);

  // --- Keyboard ---
  container.addEventListener("keydown", (e) => {
    if (e.key === "ArrowLeft") {
      prev();
      e.preventDefault();
    } else if (e.key === "ArrowRight") {
      next();
      e.preventDefault();
    }
  });

  // --- Touch / Mouse drag ---
  let startX = 0;
  let startY = 0;
  let deltaX = 0;
  let isDragging = false;
  let isHorizontal = null; // null = undecided

  function pointerDown(e) {
    // Only handle primary button / single touch
    if (e.type === "mousedown" && e.button !== 0) return;
    isDragging = true;
    isHorizontal = null;
    const point = e.touches ? e.touches[0] : e;
    startX = point.clientX;
    startY = point.clientY;
    deltaX = 0;
    track.classList.add("dragging");
  }

  function pointerMove(e) {
    if (!isDragging) return;
    const point = e.touches ? e.touches[0] : e;
    deltaX = point.clientX - startX;
    const deltaY = point.clientY - startY;

    // Decide direction on first significant move
    if (isHorizontal === null && (Math.abs(deltaX) > 5 || Math.abs(deltaY) > 5)) {
      isHorizontal = Math.abs(deltaX) > Math.abs(deltaY);
    }

    if (!isHorizontal) return; // vertical scroll, ignore

    e.preventDefault();
    const offset = -(current * viewport.offsetWidth) + deltaX;
    track.style.transform = `translateX(${offset}px)`;
  }

  function pointerUp() {
    if (!isDragging) return;
    isDragging = false;
    track.classList.remove("dragging");

    if (isHorizontal) {
      const threshold = viewport.offsetWidth * 0.2;
      if (deltaX < -threshold) next();
      else if (deltaX > threshold) prev();
      else update(); // snap back
    }
  }

  viewport.addEventListener("touchstart", pointerDown, { passive: true });
  viewport.addEventListener("touchmove", pointerMove, { passive: false });
  viewport.addEventListener("touchend", pointerUp);
  viewport.addEventListener("touchcancel", pointerUp);

  viewport.addEventListener("mousedown", pointerDown);
  viewport.addEventListener("mousemove", pointerMove);
  viewport.addEventListener("mouseup", pointerUp);
  viewport.addEventListener("mouseleave", pointerUp);

  // Initial render
  update();
}

// ──────────────────────────────────────────────
// Fullscreen overlay
// ──────────────────────────────────────────────

function openFullscreen(src) {
  const overlay = document.createElement("div");
  overlay.className = "gallery-fullscreen-overlay";
  const img = document.createElement("img");
  img.src = src;
  overlay.appendChild(img);

  overlay.addEventListener("click", () => overlay.remove());
  document.addEventListener("keydown", function handler(e) {
    if (e.key === "Escape") {
      overlay.remove();
      document.removeEventListener("keydown", handler);
    }
  });

  document.body.appendChild(overlay);
}

// ──────────────────────────────────────────────
// Plugin
// ──────────────────────────────────────────────

class GalleryPlugin extends Plugin {
  async onload() {
    this.registerMarkdownCodeBlockProcessor("gallery", (source, el, ctx) => {
      const images = parseImages(source, this.app);
      renderGallery(images, el);
    });
  }
}

module.exports = GalleryPlugin;
